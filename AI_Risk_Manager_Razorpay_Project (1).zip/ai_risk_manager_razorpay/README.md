
# AI Risk Manager for Razorpay

## Overview
AI Risk Manager is a payment-risk intelligence prototype that combines:
- Machine-learning anomaly detection
- Explainable risk signals
- Risk scoring from 0–100
- Safe / Review / High Risk decisions
- Interactive fintech dashboard

The project uses synthetic transaction data for demonstration and does not process real customer/payment data.

## Architecture

Payment Event
    ↓
FastAPI API
    ↓
Feature Extraction
    ↓
Isolation Forest ML Model
    ↓
Explainable Risk Engine
    ↓
Risk Score + Decision + Reasons
    ↓
Web Dashboard

## Tech Stack
- Python
- FastAPI
- Scikit-learn
- NumPy
- HTML5
- CSS3
- JavaScript

## Run locally

### 1. Create environment
Windows:
python -m venv venv
venv\Scripts\activate

macOS/Linux:
python3 -m venv venv
source venv/bin/activate

### 2. Install dependencies
pip install -r requirements.txt

### 3. Start server
uvicorn app:app --reload

### 4. Open
http://127.0.0.1:8000

## Demo
Try:
- Amount: 48999
- Failed attempts: 4
- Transactions in 10 minutes: 6
- Customer: New
- Behavior: Unusual

Then click Analyze Transaction.

## Important
This is a technical prototype. The ML model is trained on synthetic data. A production implementation would require validated transaction datasets, model monitoring, secure webhook verification, authentication, privacy controls, and appropriate risk/compliance review.
