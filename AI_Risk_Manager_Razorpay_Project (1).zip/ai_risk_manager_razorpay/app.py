
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sklearn.ensemble import IsolationForest
import numpy as np

app = FastAPI(title="AI Risk Manager", version="1.0.0")

# -----------------------------
# Synthetic training data
# -----------------------------
rng = np.random.default_rng(42)

# Features:
# amount, failed_attempts, velocity_10m, customer_age_days,
# amount_ratio, unusual_behavior
normal = np.column_stack([
    rng.lognormal(mean=7.0, sigma=0.65, size=2500),
    rng.poisson(0.35, 2500),
    rng.poisson(2.0, 2500),
    rng.integers(30, 1500, 2500),
    rng.normal(1.0, 0.25, 2500).clip(0.2, 2.5),
    rng.binomial(1, 0.08, 2500)
])

model = IsolationForest(
    n_estimators=250,
    contamination=0.08,
    random_state=42
)
model.fit(normal)

class Transaction(BaseModel):
    amount: float = Field(gt=0)
    failed_attempts: int = Field(ge=0, le=100)
    velocity_10m: int = Field(ge=0, le=100)
    customer_type: str = "existing"
    behavior: str = "normal"

def risk_score(tx: Transaction):
    customer_age = 20 if tx.customer_type == "new" else 500
    amount_ratio = max(tx.amount / 10000, 0.1)
    unusual = 1 if tx.behavior == "unusual" else 0

    features = np.array([[
        tx.amount,
        tx.failed_attempts,
        tx.velocity_10m,
        customer_age,
        amount_ratio,
        unusual
    ]])

    prediction = int(model.predict(features)[0])
    anomaly = float(model.decision_function(features)[0])

    # Explainable business signals layered over ML anomaly detection.
    score = 8
    reasons = []

    if tx.amount > 50000:
        score += 25
        reasons.append("Transaction amount is significantly high.")
    elif tx.amount > 20000:
        score += 15
        reasons.append("Transaction amount is above the normal range.")

    if tx.failed_attempts >= 5:
        score += 25
        reasons.append("Multiple failed payment attempts detected.")
    elif tx.failed_attempts >= 3:
        score += 18
        reasons.append("Repeated failed attempts detected.")

    if tx.velocity_10m >= 8:
        score += 22
        reasons.append("Very high transaction velocity detected.")
    elif tx.velocity_10m >= 5:
        score += 15
        reasons.append("Unusual transaction velocity detected.")

    if tx.customer_type == "new":
        score += 8
        reasons.append("Customer has limited historical transaction behavior.")

    if tx.behavior == "unusual":
        score += 18
        reasons.append("Current behavior differs from historical patterns.")

    # ML anomaly signal nudges the score.
    if prediction == -1:
        score += 8
        reasons.append("ML anomaly detector identified an unusual feature combination.")

    score = max(0, min(100, int(score)))

    if score <= 30:
        decision = "LOW RISK"
    elif score <= 70:
        decision = "REVIEW"
    else:
        decision = "HIGH RISK"

    confidence = min(98, 72 + round(score * 0.25))

    if not reasons:
        reasons.append("No major anomaly signals detected.")

    return {
        "risk_score": score,
        "decision": decision,
        "confidence": confidence,
        "reasons": reasons,
        "ml_anomaly": prediction == -1,
        "ml_signal": round(anomaly, 4)
    }

@app.get("/api/health")
def health():
    return {"status": "online", "service": "AI Risk Manager"}

@app.post("/api/analyze")
def analyze(tx: Transaction):
    return risk_score(tx)

# Serve the frontend.
app.mount("/", StaticFiles(directory="static", html=True), name="static")
